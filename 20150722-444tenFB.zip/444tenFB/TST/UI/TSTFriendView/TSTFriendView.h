//
//  TSTFriendView.h
//  444tenFB
//
//  Created by Andrey Ten on 7/19/15.
//  Copyright (c) 2015 444ten. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TSTImageModel;

@interface TSTFriendView : UIView
@property (nonatomic, strong)   IBOutlet UIImageView    *contentImageView;
@property (nonatomic, strong)   TSTImageModel           *imageModel;

@end

//
//  UIViewController+TENExtensions.h
//  444tenIOS
//
//  Created by Andrey Ten on 7/6/15.
//  Copyright (c) 2015 Andrey Ten. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (TENExtensions)

// default nib name (same as class name) and bundle nil
+ (instancetype)controller;

@end

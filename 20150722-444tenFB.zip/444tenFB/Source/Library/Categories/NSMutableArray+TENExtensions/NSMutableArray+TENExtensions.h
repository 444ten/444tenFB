//
//  NSMutableArray+TENExtensions.h
//  444tenIOS
//
//  Created by Andrey Ten on 6/22/15.
//  Copyright (c) 2015 Andrey Ten. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (TENExtensions)

- (void)moveObjectAtIndex:(NSUInteger)fromIndex toIndex:(NSUInteger)toIndex;

@end

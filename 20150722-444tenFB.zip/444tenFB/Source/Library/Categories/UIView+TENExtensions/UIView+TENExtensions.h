//
//  UIView+TENExtensions.h
//  444tenIOS
//
//  Created by Andrey Ten on 7/3/15.
//  Copyright (c) 2015 Andrey Ten. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^TENAnimationsBlock)(void);
typedef void(^TENCompletionBlock)(BOOL finished);

@interface UIView (TENExtensions)

@end

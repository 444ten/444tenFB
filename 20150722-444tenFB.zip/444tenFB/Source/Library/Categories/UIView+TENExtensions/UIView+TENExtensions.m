//
//  UIView+TENExtensions.m
//  444tenIOS
//
//  Created by Andrey Ten on 7/3/15.
//  Copyright (c) 2015 Andrey Ten. All rights reserved.
//

#import "UIView+TENExtensions.h"

@implementation UIView (TENExtensions)

@end
